import urllib2
import pprint

headers = {"TRN-Api-Key":"07e80b10-398c-4d66-9078-00fcae0d6b25"}
response = urllib2.Request("https://api.fortnitetracker.com/v1/profile/xbl/sk11hasil", headers=headers)
player_data = urllib2.urlopen(response)
print player_data["stats"]["curr_p9"]["kd"]["value"]
